import streamlit as st
import re
import os
import hashlib
import PyPDF2

# =========================================================
# PAGE CONFIGURATION
# =========================================================

st.set_page_config(
    page_title="Job Skill Extraction System",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =========================================================
# SESSION STATE
# =========================================================

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "user_email" not in st.session_state:
    st.session_state.user_email = ""

if "page" not in st.session_state:
    st.session_state.page = "login"

if "skills" not in st.session_state:
    st.session_state.skills = []

if "categories" not in st.session_state:
    st.session_state.categories = {}


# =========================================================
# USER DATABASE
# =========================================================

USER_FILE = "users.txt"


def hash_password(password):

    return hashlib.sha256(
        password.encode()
    ).hexdigest()


def register_user(email, password):

    email = email.strip().lower()

    if os.path.exists(USER_FILE):

        with open(USER_FILE, "r") as file:

            for line in file:

                saved_email, saved_password = line.strip().split(",")

                if saved_email == email:
                    return False, "Email already registered."

    with open(USER_FILE, "a") as file:

        file.write(
            f"{email},{hash_password(password)}\n"
        )

    return True, "Registration successful."


def login_user(email, password):

    email = email.strip().lower()

    if not os.path.exists(USER_FILE):
        return False

    with open(USER_FILE, "r") as file:

        for line in file:

            saved_email, saved_password = line.strip().split(",")

            if (
                saved_email == email
                and saved_password == hash_password(password)
            ):
                return True

    return False


# =========================================================
# SKILL DATABASE
# =========================================================

skill_database = [

    "Python",
    "SQL",
    "MySQL",
    "PostgreSQL",
    "Oracle",
    "MongoDB",

    "Excel",
    "Power BI",
    "Tableau",

    "Pandas",
    "NumPy",
    "Matplotlib",
    "Seaborn",

    "Machine Learning",
    "Deep Learning",
    "Natural Language Processing",
    "NLP",

    "TensorFlow",
    "PyTorch",
    "Scikit-learn",

    "Java",
    "C++",
    "R",

    "AWS",
    "Azure",
    "Google Cloud",

    "Git",
    "GitHub",

    "HTML",
    "CSS",
    "JavaScript",

    "Flask",
    "FastAPI",
    "Streamlit"
]


# =========================================================
# SKILL CATEGORIES
# =========================================================

skill_categories = {

    "Python": "Programming",
    "Java": "Programming",
    "C++": "Programming",
    "R": "Programming",
    "JavaScript": "Programming",

    "SQL": "Database",
    "MySQL": "Database",
    "PostgreSQL": "Database",
    "Oracle": "Database",
    "MongoDB": "Database",

    "Excel": "Analytics",
    "Power BI": "Business Intelligence",
    "Tableau": "Business Intelligence",

    "Pandas": "Data Science",
    "NumPy": "Data Science",
    "Matplotlib": "Data Visualization",
    "Seaborn": "Data Visualization",

    "Machine Learning": "AI / ML",
    "Deep Learning": "AI / ML",
    "Natural Language Processing": "AI / ML",
    "NLP": "AI / ML",

    "TensorFlow": "AI / ML",
    "PyTorch": "AI / ML",
    "Scikit-learn": "AI / ML",

    "AWS": "Cloud",
    "Azure": "Cloud",
    "Google Cloud": "Cloud",

    "Git": "Tools",
    "GitHub": "Tools",

    "HTML": "Web Development",
    "CSS": "Web Development",
    "Flask": "Web Development",
    "FastAPI": "Web Development",
    "Streamlit": "Web Development"
}


# =========================================================
# SKILL EXTRACTION
# =========================================================

def extract_skills(text):

    detected_skills = []

    text_lower = text.lower()

    for skill in skill_database:

        pattern = r"\b" + re.escape(skill.lower()) + r"\b"

        if re.search(pattern, text_lower):

            detected_skills.append(skill)

    return detected_skills


# =========================================================
# CATEGORY CREATION
# =========================================================

def categorize_skills(skills):

    categories = {}

    for skill in skills:

        category = skill_categories.get(
            skill,
            "Other"
        )

        if category not in categories:

            categories[category] = []

        categories[category].append(skill)

    return categories


# =========================================================
# PDF TEXT EXTRACTION
# =========================================================

def extract_pdf_text(uploaded_file):

    text = ""

    reader = PyPDF2.PdfReader(uploaded_file)

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:

            text += page_text + "\n"

    return text


# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown(
    """
    <style>

    .main-title {

        font-size: 42px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 10px;

    }

    .subtitle {

        font-size: 20px;
        text-align: center;
        margin-bottom: 30px;

    }

    .skill-box {

        padding: 15px;
        border-radius: 10px;
        border: 1px solid #ddd;
        text-align: center;
        margin-bottom: 10px;

    }

    .category-box {

        padding: 15px;
        border-radius: 10px;
        border: 1px solid #ddd;
        margin-bottom: 15px;

    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# LOGIN PAGE
# =========================================================

def login_page():

    st.markdown(
        '<div class="main-title">💼 JOB SKILL EXTRACTION SYSTEM</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">AI-Powered Job Skill Analysis</div>',
        unsafe_allow_html=True
    )

    st.divider()

    col1, col2, col3 = st.columns([1, 2, 1])

    with col2:

        st.subheader("🔐 Welcome / Login")

        email = st.text_input(
            "📧 Email ID",
            placeholder="Enter your email"
        )

        password = st.text_input(
            "🔑 Password",
            type="password",
            placeholder="Enter your password"
        )

        if st.button(
            "Login",
            use_container_width=True
        ):

            if email == "" or password == "":

                st.warning(
                    "Please enter email and password."
                )

            elif login_user(email, password):

                st.session_state.logged_in = True
                st.session_state.user_email = email
                st.session_state.page = "dashboard"

                st.rerun()

            else:

                st.error(
                    "Invalid email or password."
                )

        st.write("")

        if st.button(
            "New User? Register",
            use_container_width=True
        ):

            st.session_state.page = "register"

            st.rerun()


# =========================================================
# REGISTER PAGE
# =========================================================

def register_page():

    st.markdown(
        '<div class="main-title">💼 JOB SKILL EXTRACTION SYSTEM</div>',
        unsafe_allow_html=True
    )

    col1, col2, col3 = st.columns([1, 2, 1])

    with col2:

        st.subheader("📝 Create New Account")

        email = st.text_input(
            "📧 Email ID"
        )

        password = st.text_input(
            "🔑 Password",
            type="password"
        )

        confirm_password = st.text_input(
            "🔑 Confirm Password",
            type="password"
        )

        if st.button(
            "Create Account",
            use_container_width=True
        ):

            if email == "" or password == "":

                st.warning(
                    "Please fill all fields."
                )

            elif password != confirm_password:

                st.error(
                    "Passwords do not match."
                )

            elif "@" not in email:

                st.error(
                    "Please enter a valid email address."
                )

            else:

                success, message = register_user(
                    email,
                    password
                )

                if success:

                    st.success(message)

                    st.info(
                        "You can now login."
                    )

                else:

                    st.error(message)

        st.write("")

        if st.button(
            "← Back to Login",
            use_container_width=True
        ):

            st.session_state.page = "login"

            st.rerun()


# =========================================================
# DASHBOARD
# =========================================================

def dashboard():

    # ---------------- SIDEBAR ----------------

    st.sidebar.title("💼 Job Skill System")

    st.sidebar.write(
        f"👤 {st.session_state.user_email}"
    )

    st.sidebar.divider()

    if st.sidebar.button(
        "🏠 Dashboard",
        use_container_width=True
    ):

        st.session_state.page = "dashboard"

        st.rerun()

    if st.sidebar.button(
        "🚪 Logout",
        use_container_width=True
    ):

        st.session_state.logged_in = False
        st.session_state.user_email = ""
        st.session_state.page = "login"

        st.rerun()


    # ---------------- HEADER ----------------

    st.title(
        "📊 Job Skill Extraction Dashboard"
    )

    st.write(
        "Analyze job descriptions or resumes "
        "and automatically identify important skills."
    )

    st.divider()


    # ---------------- INPUT OPTIONS ----------------

    tab1, tab2 = st.tabs(
        [
            "📄 Job Description",
            "📤 Upload Resume"
        ]
    )


    # =================================================
    # JOB DESCRIPTION
    # =================================================

    with tab1:

        st.subheader(
            "Paste Job Description"
        )

        job_description = st.text_area(
            "Job Description",
            height=250,
            placeholder="""
Example:

We are looking for a Data Analyst
with strong knowledge of Python, SQL,
Power BI and Excel.

Experience with Tableau, Pandas,
Machine Learning and AWS is preferred.
"""
        )

        if st.button(
            "🔍 Extract Skills",
            key="job_extract",
            use_container_width=True
        ):

            if job_description.strip() == "":

                st.warning(
                    "Please enter a job description."
                )

            else:

                skills = extract_skills(
                    job_description
                )

                categories = categorize_skills(
                    skills
                )

                st.session_state.skills = skills
                st.session_state.categories = categories


    # =================================================
    # RESUME UPLOAD
    # =================================================

    with tab2:

        st.subheader(
            "Upload Resume"
        )

        uploaded_file = st.file_uploader(
            "Upload your resume",
            type=["pdf"]
        )

        if uploaded_file is not None:

            st.success(
                f"Uploaded: {uploaded_file.name}"
            )

            if st.button(
                "🔍 Extract Skills from Resume",
                key="resume_extract",
                use_container_width=True
            ):

                try:

                    resume_text = extract_pdf_text(
                        uploaded_file
                    )

                    skills = extract_skills(
                        resume_text
                    )

                    categories = categorize_skills(
                        skills
                    )

                    st.session_state.skills = skills
                    st.session_state.categories = categories

                    st.success(
                        "Resume analyzed successfully!"
                    )

                except Exception as e:

                    st.error(
                        f"Error reading resume: {e}"
                    )


    # =================================================
    # RESULTS
    # =================================================

    if st.session_state.skills:

        st.divider()

        st.header(
            "🎯 Detected Skills"
        )

        skills = st.session_state.skills

        columns = st.columns(4)

        for i, skill in enumerate(skills):

            with columns[i % 4]:

                st.success(
                    f"✓ {skill}"
                )


        # =================================================
        # CATEGORIES
        # =================================================

        st.header(
            "📂 Skill Categories"
        )

        categories = st.session_state.categories

        for category, category_skills in categories.items():

            st.markdown(
                f"### 📌 {category}"
            )

            cols = st.columns(
                len(category_skills)
                if len(category_skills) < 4
                else 4
            )

            for i, skill in enumerate(
                category_skills
            ):

                with cols[i % len(cols)]:

                    st.info(
                        f"→ {skill}"
                    )


        # =================================================
        # SUMMARY
        # =================================================

        st.divider()

        col1, col2 = st.columns(2)

        with col1:

            st.metric(
                "Total Skills Detected",
                len(skills)
            )

        with col2:

            st.metric(
                "Skill Categories",
                len(categories)
            )


# =========================================================
# MAIN APPLICATION CONTROL
# =========================================================

if st.session_state.page == "login":

    login_page()

elif st.session_state.page == "register":

    register_page()

elif st.session_state.page == "dashboard":

    if st.session_state.logged_in:

        dashboard()

    else:

        st.session_state.page = "login"

        st.rerun()